from ProxyPattern import ProxyPattern

internet = ProxyPattern()
internet.connect_to('www.google.com')
internet.connect_to('abc.com')

