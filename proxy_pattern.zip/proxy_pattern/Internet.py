from abc import ABC, abstractmethod

class Internet(ABC):
    def connect_to(self):
        pass