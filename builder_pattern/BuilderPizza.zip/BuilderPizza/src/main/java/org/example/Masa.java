package org.example;

public class Masa {

}
