package org.example;

public class Cobertura {
}
