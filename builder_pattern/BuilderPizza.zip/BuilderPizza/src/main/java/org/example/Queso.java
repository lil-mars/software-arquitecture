package org.example;

public class Queso {
}
