package org.example;

public class Base {
}
