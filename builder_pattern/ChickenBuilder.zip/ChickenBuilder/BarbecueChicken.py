from Chicken import Chicken

class BarbecueChicken(Chicken):
    def __init__(self):
        super().__init__()

    