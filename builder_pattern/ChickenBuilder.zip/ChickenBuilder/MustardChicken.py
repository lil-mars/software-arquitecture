from Chicken import Chicken

class MustardChicken(Chicken):
    def __init__(self):
        super().__init__()

