package org.example;

class  DomesticPlan extends Plan{
    //@override
    public void getRate(){
        rate=3.50;
    }
}//end of DomesticPlan class.
