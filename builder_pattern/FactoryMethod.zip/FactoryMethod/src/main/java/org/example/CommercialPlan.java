package org.example;

class  CommercialPlan extends Plan {
    //@override
    public void getRate() {
        rate = 7.50;
    }
}
//end of CommercialPlan class.
