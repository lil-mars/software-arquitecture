
class Context:
    def __init__(self, expression):
        self.expression = expression
        self.value = 0
        self.numbers = []
        self.operators = []