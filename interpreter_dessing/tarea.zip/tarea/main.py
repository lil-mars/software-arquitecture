from Parser import Parser

expression = 'uno mas uno mas dos menos uno mas cinco mas uno menos nueve'
parser = Parser(expression)
print(parser.get_result())