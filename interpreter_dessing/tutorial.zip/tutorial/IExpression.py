from abc import ABC
class Expression(ABC):
    def interpret(self, context):
        pass