package org.example;
//Interfaz que conoce el Cliente
public interface ITarget {
    int sumar(int numero1, int numero2);
}

