from Workshop import WorkShop
class Assemble(WorkShop):
    def work(self):
        print('Ensamblando vehiculo')