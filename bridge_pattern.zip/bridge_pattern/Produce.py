from Workshop import WorkShop

class Produce(WorkShop):
    def work(self):
        print('Produciendo el vehiculo')