from abc import ABC

class ICharge():
    def charge(self, quantity, unit_price):
        pass
