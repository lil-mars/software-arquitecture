class Text:
    def __init__(self, text):
        self.text = text
    def make_bold(self):
        print('Texto esta en negrita')

    def remove_bold(self):
        print('Texto sin negrita')

    def change_color(self, color):
        print(f'Texto color: {color}')
    
    def justify(self):
        print('Texo justificado')

    def remove_justify(self):
        print('Texto sin justificacion')